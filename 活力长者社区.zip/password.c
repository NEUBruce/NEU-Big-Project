#define _CRT_SECURE_NO_WARNINGS 1
#include"password.h"
#include "building.h"
#include "hotel.h"
void initPassword()
{
	FILE* codebook;
	codebook = fopen("codebook.txt", "r");
	if (codebook == NULL)
	{
		codebook = fopen("codebook.txt", "w");
		fprintf(codebook, "����:%s", "12345678");
		strcpy(password, "12345678");
		fclose(codebook);
	}
	else
	{
		fgetc(codebook);
		fgetc(codebook);
		fgetc(codebook);
		fgetc(codebook);
		fgetc(codebook);
		for (int i = 0;; i++)
		{
			password[i] = fgetc(codebook);
			if (password[i] == EOF || password[i] == '\n')
			{
				password[i] = '\0';
				break;
			}
		}
		fclose(codebook);
	}

}

void changePassword()
{
	system("cls");
	printf("���ã�����������:> ");
	int ensure = passwordEnsure();
	if (ensure != 0)
	{
		printf("�������!\n");
		system("pause");
		system("cls");
		return;
	}
	else
	{
		printf("\n");
		printf("������������:> ");
		char newPassword[PASSWORD_LENGTH];
		scanf("%s", newPassword);
		printf("���ٴ�ȷ��������:> ");
		char tmpPassword[PASSWORD_LENGTH];
		scanf("%s", tmpPassword);
		if (!strcmp(newPassword, tmpPassword))
		{
			memset(password, 0, sizeof(password));
			strcpy(password, newPassword);
			FILE* codebook;
			codebook = fopen("codebook.txt", "w+");
			fprintf(codebook, "����:%s\n", password);
			fclose(codebook);
			printf("�޸ĳɹ���\n");
			system("pause");
			system("cls");
			return;
		}
		else
		{
			printf("������������벻��ͬ,�����޸�ʧ�ܣ�\n");
			system("pause");
			system("cls");
			return;
		}
	}
}

int passwordEnsure()
{
	char input[100];
	scanf("%s", input);
	return strcmp(password, input);
}